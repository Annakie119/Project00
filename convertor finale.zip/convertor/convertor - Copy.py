from PyQt5 import QtWidgets, uic, QtGui
from PyQt5.QtWidgets import QMessageBox, QTableWidgetItem
import pyodbc

# Dictionary for conversion rates
conversion_rates = {
    ("Namibia", "America"): 0.067,
    ("America", "Namibia"): 14.92,
    ("Namibia", "Nigeria"): 29.42,
    ("Nigeria", "Namibia"): 0.034,
    ("Namibia", "China"): 0.48,
    ("China", "Namibia"): 2.08,
    ("Namibia", "UK"): 0.043,
    ("UK", "Namibia"): 23.15,
    ("Namibia", "Dubai"): 0.25,
    ("Dubai", "Namibia"): 4.0,
    # Add more rates as needed
}

# Connect to SQL Server
def get_db_connection():
    connection = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=Psalms23\LOCALDB#05493B38;'
        'DATABASE=CONVERTOR;'
        #'UID=your_username;'
        #'PWD=your_password'
    )
    return connection

# Save conversion to database
def save_to_database(Amount, Result, From_currency, to_currency):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO Table_2024 (Amount, Result, From_currency, to_currency) VALUES (?, ?, ?, ?)", 
            (Amount, Result, From_currency, to_currency)
        )
        conn.commit()
    except Exception as e:
        print("Error saving to database:", e)
        QMessageBox.warning(dlg, "Database Error", "An error occurred while saving to the database.")
    finally:
        conn.close()

# Load conversion history from database to Qt table
def load_history():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Table_2024")
        rows = cursor.fetchall()

        history_dlg.tableWidget.setRowCount(len(rows))
        for row_index, row_data in enumerate(rows):
            for col_index, value in enumerate(row_data):
                item = QTableWidgetItem(str(value))
                history_dlg.tableWidget.setItem(row_index, col_index, item)

    except Exception as e:
        print("Error loading history:", e)
        QMessageBox.warning(history_dlg, "Database Error", "An error occurred while loading the history.")
    finally:
        conn.close()

# Perform currency conversion
def Convert():
    try:
        amount = float(dlg.lineEdit.text())
        from_currency = dlg.comboBox_from.currentText()
        to_currency = dlg.comboBox_to.currentText()

        rate = conversion_rates.get((from_currency, to_currency))
        if rate is None and (to_currency, from_currency) in conversion_rates:
            rate = 1 / conversion_rates[(to_currency, from_currency)]
        
        if rate is None:
            QMessageBox.warning(dlg, "Conversion Error", f"No conversion rate available for {from_currency} to {to_currency}.")
            return

        result = amount * rate
        dlg.lineEdit_2.setText(str(round(result, 2)))
        save_to_database(amount, result, from_currency, to_currency)

    except ValueError:
        QMessageBox.warning(dlg, "Input Error", "Please enter a valid number.")

# Initialize app and main UI
app = QtWidgets.QApplication([])
dlg = uic.loadUi("Convertor.ui")
history_dlg = uic.loadUi("history.ui")

# Set up navigation between pages
dlg.viewHistoryButton.clicked.connect(lambda: (history_dlg.show(), load_history()))
history_dlg.backButton.clicked.connect(lambda: (history_dlg.close(), dlg.show()))

# Populate combo boxes with countries and flags
countries = ["Namibia", "America", "Nigeria", "China", "UK", "Dubai"]
flags = {
    "Namibia": "namibia.png",
    "America": "USA.png",
    "Nigeria": "Flag_of_Nigeria.png",
    "China": "china_flag.png",
    "UK": "uk.png",
    "Dubai": "Flag_of_the_United_Arab_Emirates.svg.png"
}

for country in countries:
    icon = QtGui.QIcon(flags[country])
    dlg.comboBox_from.addItem(icon, country)
    dlg.comboBox_to.addItem(icon, country)

# Connect the convert button
dlg.pushButton.clicked.connect(Convert)

# Show the main dialog
dlg.show()
app.exec()
