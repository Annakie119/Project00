<RCC>
    <qresource prefix="/">
        <file alias="namibia.png">path/to/namibia.png</file>
        <file alias="USA.png">path/to/USA.png</file>
        <file alias="Flag_of_Nigeria.png">path/to/Flag_of_Nigeria.png</file>
        <file alias="china_flag.png">path/to/china_flag.png</file>
        <file alias="uk.png">path/to/uk.png</file>
        <file alias="Flag_of_the_United_Arab_Emirates.svg.png">path/to/Flag_of_the_United_Arab_Emirates.svg.png</file>
    </qresource>
</RCC>

